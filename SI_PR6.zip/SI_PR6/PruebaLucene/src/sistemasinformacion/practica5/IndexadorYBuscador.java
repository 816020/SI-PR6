package sistemasinformacion.practica5;

import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.document.TextField;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.Field;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.es.SpanishAnalyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.core.SimpleAnalyzer;

import org.apache.lucene.store.Directory;
import org.apache.lucene.store.MMapDirectory;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;


import java.util.ArrayList;
import java.util.Collection;
import java.io.IOException;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.File;
import java.io.InputStreamReader;
import java.nio.file.Paths;
import java.io.BufferedReader;
import java.util.Scanner;


/**
 * Clase de ejemplo de un indexador y buscador usando Lucene
 * @author sisinf
 *
 */
public class IndexadorYBuscador{

	/**
	 * Relación de ficheros a indexar / buscar
	 */
	private Collection <String> ficherosAIndexar = new ArrayList<String>();
	/**
	 * Relación de palabras clave a buscar
	 */
	private Collection <String> queries = new ArrayList <String>();
	/**
	 * Analizar utilizado por el indexador / buscador 
	 */
	private Analyzer analizador;
	
	private final static String INDEXDIR = "../doc/indice";
	
	

	/**
	 * Constructor parametrizado
	 * @param ficherosAIndexar Colección de ficheros a indexar
	 * @param queries Colección de palabras a buscar
	 */
	public IndexadorYBuscador(Collection<String> ficherosAIndexar, Collection<String> queries){
		this.ficherosAIndexar = ficherosAIndexar;
		this.queries = queries;
		
		//analizador = new SimpleAnalyzer();
		
		try {
			FileReader reader = new FileReader("./ficheros/stopwords.txt");
			analizador = new StandardAnalyzer(reader);
		} catch (Exception e) {
			System.out.println("Error leyendo fichero de Stop Words. Usando valor por defecto");
			analizador = new StandardAnalyzer();
		} //
		
		//analizador = new SpanishAnalyzer();

	
	}
	
	
	
	/**
	 * Añade un fichero al índice
	 * @param indice Indice que estamos construyendo
	 * @param path ruta del fichero a indexar
	 * @throws IOException
	 */
	private void anhadirFichero(IndexWriter indice, String path) 
	throws IOException {
		InputStream inputStream = new FileInputStream(path);
		BufferedReader inputStreamReader = new BufferedReader(
				new InputStreamReader(inputStream,"UTF-8"));
		
		Document doc = new Document();   
		doc.add(new TextField("contenido", inputStreamReader));
		doc.add(new StringField("path", path, Field.Store.YES));
		indice.addDocument(doc);
	}
	
	
	
	/**
	 * Indexa los ficheros incluidos en "ficherosAIndexar"
	 * @return un índice (Directory) en memoria, con los índices de los ficheros
	 * @throws IOException
	 */
	private Directory crearIndiceEnUnDirectorio() throws IOException{
		IndexWriter indice = null;
		Directory directorioAlmacenarIndice = new MMapDirectory(Paths.get(INDEXDIR));

		IndexWriterConfig configuracionIndice = new IndexWriterConfig(analizador);

		indice = new IndexWriter(directorioAlmacenarIndice, configuracionIndice);
		
		for (String fichero : ficherosAIndexar) {
			anhadirFichero(indice, fichero);
		}
		
		indice.close();
		return directorioAlmacenarIndice;
	}
	
	public void borrarIndices() throws IOException {
	    IndexWriterConfig config = new IndexWriterConfig(analizador);
	    Directory directorio = MMapDirectory.open(Paths.get(INDEXDIR));
	    IndexWriter indice = new IndexWriter(directorio, config);
	    indice.deleteAll();
	}

	
	/**
	 * Busca la palabra indicada en queryAsString en el directorioDelIndice.
	 * @param directorioDelIndice
	 * @param paginas
	 * @param hitsPorPagina
	 * @param queryAsString
	 * @throws IOException
	 */
	private void buscarQueryEnIndice(Directory directorioDelIndice, 
										int paginas, 
										int hitsPorPagina, 
										String queryAsString)
	throws IOException{

		DirectoryReader directoryReader = DirectoryReader.open(directorioDelIndice);
		IndexSearcher buscador = new IndexSearcher(directoryReader);
		
		QueryParser queryParser = new QueryParser("contenido", analizador); 
		Query query = null;
		try{
			query = queryParser.parse(queryAsString);
			TopDocs resultado = buscador.search(query, paginas * hitsPorPagina);
			ScoreDoc[] hits = resultado.scoreDocs;
		      
			System.out.println("\nBuscando " + queryAsString + ": Encontrados " + hits.length + " hits.");
			int i = 0;
			for (ScoreDoc hit: hits) {
				int docId = hit.doc;
				
				Document doc = buscador.doc(docId);
				System.out.println((++i) + ". " + doc.get("path") + "\t" + hit.score);
			}

		}catch (ParseException e){
			throw new IOException(e);
		}	
	}
	
	
	
	/**
	 * Ejecuta en el índice una búsqueda por cada una de las palabras clave solicitadas. <p>
	 * Las palabras clave solicitadas están en la propiedad global "queries". 
	 * @param directorioDelIndice índice
	 * @param paginas 
	 * @param hitsPorPagina
	 * @throws IOException
	 */
	private void buscarQueries(Directory directorioDelIndice, int paginas, int hitsPorPagina)
	throws IOException{
		for (String palabra : queries) {
			buscarQueryEnIndice(directorioDelIndice, 
								paginas, 
								hitsPorPagina, 
								palabra);			
		}
	}
	
public static void menu(Scanner scanner, Collection <String> ficheros, Collection <String> queries, IndexadorYBuscador ejemplo, Directory directorioDelIndiceCreado) throws IOException {	
    // Mostramos el men�
    System.out.println("Selecciona una opción del menú:");
    System.out.println("1. Indexar un directorio");
    System.out.println("2. Añadir un documento al índice");
    System.out.println("3. Buscar término");
    System.out.println("4. Salir");
	
	
    // Leemos la opci�n elegida por el usuario
    int opcion = scanner.nextInt();

    // Ejecutamos el c�digo correspondiente a la opci�n elegida
    switch (opcion) {
        case 1:
            // C�digo para la opci�n 1
            System.out.println("Escribe la dirección del directorio a indexar: ");
            
            String path = scanner.next();
            File directorio = new File(path);
            for (File archivo : directorio.listFiles()) {
            	ficheros.add(archivo.getAbsolutePath());
            }
            System.out.println("El directorio " + path + " ha sido añadido al índice.");
            System.out.println("");
            menu(scanner, ficheros, queries, ejemplo, directorioDelIndiceCreado);
            break;
        case 2:
            // Código para la opción 2
            System.out.println("Escribe la dirección del documento para añadirlo al índice: ");
            path = scanner.next();
            ficheros.add(path);
            directorioDelIndiceCreado = ejemplo.crearIndiceEnUnDirectorio();
            System.out.println("El documento " + path + " ha sido añadido al índice.");
            System.out.println("");
            menu(scanner, ficheros, queries, ejemplo, directorioDelIndiceCreado);
            break;

        case 3:
            // Código para la opción 3
            System.out.println("Escribe un término para buscarlo en el índice: ");
            String termino = scanner.next();
            queries.clear();
            queries.add(termino);
            if (!ficheros.isEmpty()) {
                ejemplo.buscarQueries(directorioDelIndiceCreado, ficheros.size(), 1);
            } else {
            	System.out.println("");
                System.out.println("No se han añadido ficheros al índice, no se pueden buscar términos");
            }
            System.out.println("");
            menu(scanner, ficheros, queries, ejemplo, directorioDelIndiceCreado);
            break;

        case 4:
            // Código para la opción 4
            System.out.println("Saliendo ...");
            break;
        default:
            // Si se introduce una opción inválida
            System.out.println("Opción inválida");
            System.out.println("");
            
            menu(scanner, ficheros, queries, ejemplo, directorioDelIndiceCreado);
            break;
    }
}
	
	/**
	 * Programa principal de prueba. Rellena las colecciones "ficheros" y "queries"
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[]args) throws IOException{

		Collection <String> ficheros = new ArrayList <String>();
		Scanner scanner = new Scanner(System.in);
		Collection <String> queries = new ArrayList <String>();
		IndexadorYBuscador ejemplo = new IndexadorYBuscador(ficheros, queries);
		Directory directorioDelIndiceCreado = ejemplo.crearIndiceEnUnDirectorio();
		
		menu(scanner, ficheros, queries, ejemplo, directorioDelIndiceCreado);

		ejemplo.borrarIndices();
	}
	
}


